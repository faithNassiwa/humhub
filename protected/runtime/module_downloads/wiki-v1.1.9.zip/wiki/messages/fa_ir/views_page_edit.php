<?php
return array (
  '<strong>Create</strong> new page' => '<strong>ایجاد</strong> صفحه‌ی جدید',
  '<strong>Edit</strong> page' => '<strong>ویرایش</strong> صفحه',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'نام یا آدرس یک صفحه‌ی ویکی را وارد کنید (برای مثال http://example.com)',
  'New page title' => 'عنوان صفحه‌ی جدید',
  'Page content' => 'محتوای صفحه',
  'Save' => 'ذخیره',
);
