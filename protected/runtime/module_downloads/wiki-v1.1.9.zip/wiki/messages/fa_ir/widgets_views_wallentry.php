<?php
return array (
  'Open wiki page...' => 'بازكردن صفحه ويكي',
);
