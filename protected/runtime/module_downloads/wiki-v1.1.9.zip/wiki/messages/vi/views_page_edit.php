<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Tạo</strong> trang mới',
  '<strong>Edit</strong> page' => '<strong>Chỉnh sửa</strong> trang',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Nhập tên hoặc địa chỉ url của trang Kiến thức (VD: http://vidu.com)',
  'New page title' => 'Tiêu đề trang mới',
  'Page content' => 'Nội dung trang',
  'Save' => 'Lưu',
);
