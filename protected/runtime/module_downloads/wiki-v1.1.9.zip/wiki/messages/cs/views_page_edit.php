<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Vytvoření</strong> nové stránky',
  '<strong>Edit</strong> page' => '<strong>Změna</strong> stránky',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Zadejte  název wiki stránky  nebo URL odkaz (např.: http://priklad.cz)',
  'New page title' => 'Titulek stránky',
  'Page content' => 'Obsah stránky',
  'Save' => 'Uložit',
);
