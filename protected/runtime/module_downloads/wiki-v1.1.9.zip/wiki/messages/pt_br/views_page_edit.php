<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Criar</strong> nova página',
  '<strong>Edit</strong> page' => '<strong>Editar</strong> página',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Insira o nome ou url da página Wiki (ex. http://exemplo.com)',
  'New page title' => 'Título da nova página',
  'Page content' => 'Conteúdo da página',
  'Save' => 'Salvar',
);
