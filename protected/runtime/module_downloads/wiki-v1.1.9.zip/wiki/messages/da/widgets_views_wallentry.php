<?php
return array (
  'Open wiki page...' => 'Åbn wiki side...',
);
