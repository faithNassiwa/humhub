<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Cumpleaños</strong> dentro de los siguientes {days} días',
  'Back to modules' => 'Regresar a los Módulos',
  'Birthday Module Configuration' => 'Configuración del módulo Cumpleaños',
  'In {days} days' => 'En {days} días',
  'Save' => 'Guardar',
  'The number of days future bithdays will be shown within.' => 'Número de días para mostrar los siguientes cumpleaños.',
  'Tomorrow' => 'Mañana',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Debes configurar el número de días para mostrar los cumpleaños.',
  'becomes {years} years old.' => 'cumplirá {years} años de edad.',
  'today' => 'hoy',
);
