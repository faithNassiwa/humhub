<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>روز آینده{days}تولد های موجود در</strong>',
  'Back to modules' => 'بازگشت‌ به ماژول‌‌ها',
  'Birthday Module Configuration' => 'پیکربندی ماژول زادروز',
  'In {days} days' => 'آینده {days} در',
  'Save' => 'ذخیره',
  'The number of days future bithdays will be shown within.' => 'تعداد روزهایی که زادروز، قبل از فرا رسیدن یادآوری می‌شود.',
  'Tomorrow' => 'فردا',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'شما می‌توانید تعداد روزهایی که زادروزهای نزدیک یادآوری می‌شوند تنظیم کنید. ',
  'becomes {years} years old.' => 'ساله می شود {years}',
  'today' => 'امروز',
);
