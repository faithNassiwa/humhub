<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Aniversari</strong> de-a lungul a {days} zile',
  'Back to modules' => 'Înapoi la module',
  'Birthday Module Configuration' => 'Configurare Modul Aniversări',
  'In {days} days' => 'In {days} zile',
  'Save' => 'Salvează',
  'The number of days future bithdays will be shown within.' => 'Numărul zilelor afișate în aniversările viitoare.',
  'Tomorrow' => 'Mâine',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Poți configura numărul zilelor în care aniversările viitoare vor fi afișate.',
  'becomes {years} years old.' => 'implineste {years} de ani',
  'today' => 'azi',
);
