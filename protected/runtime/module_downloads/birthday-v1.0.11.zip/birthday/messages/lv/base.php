<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Dzimšanas dienas</strong> nākamajās {days} dienās',
  'Back to modules' => 'Atpakaļ uz moduļiem',
  'Birthday Module Configuration' => 'Dzimšanas dienu moduļa konfigurācija',
  'In {days} days' => 'Pēc {days} dienas/-ām',
  'Save' => 'Saglabāt',
  'The number of days future bithdays will be shown within.' => 'Dienu skaits kad tuvojošās dzimšanas dienas tiks parādītas.',
  'Tomorrow' => 'Rītdien',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Tu vari konfigurēt dienu skaitu kad parādīsies tuvojošās dzimšanas dienas.',
  'becomes {years} years old.' => 'aprit {years} gadi.',
  'today' => 'šodien',
);
