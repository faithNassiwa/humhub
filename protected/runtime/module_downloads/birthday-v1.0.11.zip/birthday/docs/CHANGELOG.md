Changelog
=========

1.0.11 - October 9, 2017
------------------------
- Fix: Incorrect order on many birthdays at the same time range
