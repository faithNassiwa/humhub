<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Opprett</strong> ny aktiviteststype',
  '<strong>Create</strong> new type' => '<strong>Opprett</strong> ny type',
  '<strong>Edit</strong> event type' => '<strong>Rediger</strong> aktivitetstype',
);
