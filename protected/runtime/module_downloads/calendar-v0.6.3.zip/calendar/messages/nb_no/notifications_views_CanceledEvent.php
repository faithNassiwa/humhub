<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} har avlyst aktivitet \'{contentTitle}\' i gruppen {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} har avlyst aktivitet \'{contentTitle}\'.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} har oppdatert aktivitet {contentTitle} i gruppen {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} har oppdatert aktivitet {contentTitle}.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} har gjenåpnet aktivitet {contentTitle} i gruppen {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} har gjenåpnet aktivitet {contentTitle}.',
);
