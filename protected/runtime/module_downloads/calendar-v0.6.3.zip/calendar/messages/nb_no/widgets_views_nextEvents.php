<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Kommende</strong> events',
  'Open Calendar' => 'Åpne Kalender',
);
