<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% deltar på %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% deltar kanskje på %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% deltar ikke på %contentTitle%.',
);
