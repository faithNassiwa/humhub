<?php
return array (
  '<strong>Create</strong> event' => '<strong>Opprett</strong> aktivitet',
  '<strong>Edit</strong> event' => '<strong>Rediger</strong> aktivitet',
  'Basic' => 'Om',
  'Everybody can participate' => 'Med påmelding',
  'Files' => 'Vedlegg',
  'No participants' => 'Uten påmelding',
  'Participation' => 'Påmelding',
  'Select event type...' => 'Velg aktivitetstype',
  'Title' => 'Tittel',
);
