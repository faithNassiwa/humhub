<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% participă la %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% probabil participă la %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nu participă la %contentTitle%.',
);
