<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% посетит %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% возможно посетит %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% не посетит %contentTitle%.',
);
