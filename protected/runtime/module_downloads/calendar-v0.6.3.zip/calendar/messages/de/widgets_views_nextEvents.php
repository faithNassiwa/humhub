<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Nächste</strong> Termine ',
  'Open Calendar' => 'Kalender öffnen',
);
