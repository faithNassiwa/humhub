<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Crea</strong> un nuovo tipo di evento',
  '<strong>Create</strong> new type' => '<strong>Crea</strong> un nuovo tipo',
  '<strong>Edit</strong> event type' => '<strong>Modifica</strong> il tipo di evento',
);
