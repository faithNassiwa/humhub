<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtro</strong> eventi',
  '<strong>Select</strong> calendars' => '<strong>Seleziona</strong> calendari',
  'Already responded' => 'Già risposto',
  'Followed spaces' => 'Space che seguo',
  'Followed users' => 'Utenti che seguo',
  'I´m attending' => 'Partecipo',
  'My events' => 'I miei eventi',
  'My profile' => 'il mio profilo',
  'My spaces' => 'I miei space',
  'Not responded yet' => 'Non risposto',
);
