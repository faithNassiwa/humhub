<?php
return array (
  '<strong>Create</strong> event' => '<strong>Créer</strong> un événement',
  '<strong>Edit</strong> event' => '<strong>Modifier</strong> un événement',
  'Basic' => 'Basique',
  'Everybody can participate' => 'Tout le monde peut participer',
  'Files' => 'Fichiers',
  'No participants' => 'Pas de participant',
  'Participation' => 'Participation',
  'Select event type...' => 'Sélectionner un type d\'événement...',
  'Title' => 'Titre',
);
