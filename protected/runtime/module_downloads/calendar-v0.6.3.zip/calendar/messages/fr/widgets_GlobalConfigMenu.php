<?php
return array (
  'Defaults' => 'Par défaut',
  'Event Types' => 'Types d\'événement',
  'Snippet' => 'Extrait',
);
